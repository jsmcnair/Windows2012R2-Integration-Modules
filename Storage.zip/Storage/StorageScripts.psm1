############################
#
# Copyright (c) Microsoft Corporation
#
# Abstract:
#   This script cmdlet enumerates SMAPI MSFT_StorageNodeToPhysicalDisk
#   objects and filters by a StorageNode, PhysicalDisk, or both, if 
#   passed in as parameters.
#
############################

function Get-PhysicalDiskStorageNodeView {
[CmdletBinding()]
param(
    [Microsoft.Management.Infrastructure.CimInstance]
    [PSTypeName("Microsoft.Management.Infrastructure.CimInstance#ROOT/Microsoft/Windows/Storage/MSFT_StorageNode")] 
    [Parameter(
        ValueFromPipeline=$true)]
    $StorageNode = $null,

    [Microsoft.Management.Infrastructure.CimInstance]
    [PSTypeName("Microsoft.Management.Infrastructure.CimInstance#ROOT/Microsoft/Windows/Storage/MSFT_PhysicalDisk")] 
    [Parameter(
        ValueFromPipeline=$true)]
    $PhysicalDisk = $null
    )

## Gather the association objects
$instances = Get-CimInstance -Namespace root\microsoft\windows\storage -ClassName MSFT_StorageNodeToPhysicalDisk

## Filter by StorageNode and PhysicalDisk ObjectIds
ForEach ( $instance in $instances ) {
    if ( $StorageNode ) {
        if ( $instance.StorageNodeObjectId -ne $StorageNode.ObjectId ) {
            continue
        }
    }

    if ( $PhysicalDisk ) {
        if ( $instance.PhysicalDiskObjectId -ne $PhysicalDisk.ObjectId ) {
            continue
        }
    }

    $instance
}
}

New-Alias Get-PhysicalDiskSNV Get-PhysicalDiskStorageNodeView

Export-ModuleMember -Alias * -Function *